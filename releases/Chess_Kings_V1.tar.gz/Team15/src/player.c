//source file for player functions

#include <stdlib.h>
#include "player.h"
#include "pieces.h"
#include "moveList.h"

Player *createPlayer(Color color, PlayerType type)
{
  Player *newPlayer = malloc(sizeof(Player));

  newPlayer->playerColor = color;
  newPlayer->type = type;
  newPlayer->isInCheckmate = 0; //default a Player to not be in checkmate when it is created

  return newPlayer;
}

void deletePlayer(Player *player)
{
  free(player);
}

MoveList *getAllPossibleMoves(Player *player)
{
  MoveList *possibleMoveList = createMoveList();

  for (int i = 0; i < sizeof(player->playerPieces) / sizeof(player->playerPieces[0]); i++)
  {
    if (player->playerPieces[i] == NULL)
    {
      continue;
    }
    else
    {
      appendMoveLists(getAllPossibleMoves(player), possibleMoveList);
    }
  }
  return possibleMoveList;
}