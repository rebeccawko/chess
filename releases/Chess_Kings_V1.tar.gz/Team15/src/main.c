#include <stdio.h>

#include "chessStructs.h"
#include "board.h"
#include "square.h"
#include "pieces.h"
#include "player.h"
#include "moveList.h"

int main()
{

  Board *thisGameBoard = createGameBoard();
  populateGameBoard(thisGameBoard);

  moveChessPiece(thisGameBoard->chessBoard[2][1]->thisSquaresPiece, thisGameBoard->chessBoard[2][2], thisGameBoard);
  moveChessPiece(thisGameBoard->chessBoard[2][2]->thisSquaresPiece, thisGameBoard->chessBoard[2][3], thisGameBoard);
  moveChessPiece(thisGameBoard->chessBoard[2][3]->thisSquaresPiece, thisGameBoard->chessBoard[2][4], thisGameBoard);
  moveChessPiece(thisGameBoard->chessBoard[2][4]->thisSquaresPiece, thisGameBoard->chessBoard[2][5], thisGameBoard);

  int result = checkValidMove(thisGameBoard->chessBoard[2][5]->thisSquaresPiece, thisGameBoard->chessBoard[3][6], thisGameBoard);
  printf("\n%d", result);
}