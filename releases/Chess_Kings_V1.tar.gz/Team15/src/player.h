//header file to represent chess player

#ifndef __PLAYER_H__
#define __PLAYER_H__

#include "chessStructs.h"

Player *createPlayer(Color color, PlayerType type);

void deletePlayer(Player *player);

int playerCheck(Player *player); //returns 1 if player's king is in check, 0 otherwise

int playerCheckMate(Player *player); //returns 1 if player's king is in checkmate, 0 otherwise.

int checkValidCastling(Player *player); //return 1 if player can castle, 0 otherwise

MoveList *getAllPossibleMoves(Player *player); //return a list of all of a player's valid moves

#endif