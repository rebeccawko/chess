//Header file to represent board and board operations
#ifndef __BOARD_H__
#define __BOARD_H__

#include "chessStructs.h"

Board *createGameBoard(void); //allocate memory for gameboard

void deleteGameBoard(Board *gameBoard); //deallocate memory for gameboard

void populateGameBoard(Board *gameBoard); //sets the initial positions for all the game pieces

void printBoard(Board *gameBoard); //print game board

#endif